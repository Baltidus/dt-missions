<?php

namespace Doctrine\DBAL\ArrayParameters;

use Throwable;

/** @internal */
interface Exception extends Throwable
{
}
